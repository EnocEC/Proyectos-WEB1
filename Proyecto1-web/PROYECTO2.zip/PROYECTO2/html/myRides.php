<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/myRides.css">
    <title>My Rides</title>

</head>

<body>

    <main class="container">
        <header class="logo">
            <img src="../imagenes/logoAventones.png" alt="Logo Aventones">
        </header>

        <div class="navContainer">
            <nav>
                <a href="searchRides.php" class="boton">Inicio</a>
                <a href="myRides.php" class="boton Rides">Rides</a>
                <a href="reservas.php" class="boton">Reservas</a>
                <a href="vehiculos.php" class="boton">Vehiculos</a>
                <a href="editProfile.php" class="boton">Perfil</a>
            </nav>

            <div class="search">
                <img src="../imagenes/user.png" id="user" alt="User">
            </div>

        </div>

        <section class="title">
            <h1>Rides</h1>
            <hr>
        </section>

        <div class="newRide">
            <a href="newRide.php" class="boton newR">New Ride</a>
        </div>

        <div class="table">
            <table>
                <thead>
                    <tr>
                        <th>Salida</th>
                        <th>Llegada</th>
                        <th class="sizeTh">Nombre</th>
                        <th>Dia</th>
                        <th>Asientos</th>
                        <th>Costo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    session_start();
                    include("abrir_con.php");

                    $id_user = $_SESSION['id_user'];

                    $consulta = mysqli_query($conexion, "SELECT * FROM rides WHERE id_user = $id_user");
                    ?>

                    <?php while ($ride = mysqli_fetch_assoc($consulta)): ?>
                        <tr>
                            <td><?= $ride['salida'] ?></td>
                            <td><?= $ride['llegada'] ?></td>
                            <td><?= $ride['nombre'] ?></td>
                            <td><?= $ride['dia'] ?></td>
                            <td><?= $ride['cantidad'] ?></td>
                            <td><?= $ride['costo'] ?></td>
                            <td><a href="editRide.php?id=<?= $ride['id'] ?>">Editar</a>
                            | <a href="deleteRide.php?id=<?= $ride['id'] ?>" 
                            onclick="return confirm('¿Estás seguro de que deseas eliminar este ride?');">Eliminar</a></td>
                        </tr>
                    <?php endwhile; ?>

                </tbody>
            </table>
        </div>

    </main>

</body>

</html>

<?php
include("cerrar_con.php");
?>