<?php
session_start();
include("abrir_con.php");

if (isset($_POST['btn'])) {

    $salida = $_POST['salida'];
    $llegada = $_POST['llegada'];
    $nombre = $_POST['nombre'];
    $dias = $_POST['dias'];
    $cantidad = $_POST['cantidad'];
    $costo = $_POST['costo'];
    $fecha = $_POST['fecha'];
    $modelo = $_POST['modelo'];

    $id_user = $_SESSION['id_user'];

    $buscarId = mysqli_query($conexion, "SELECT id FROM vehiculos WHERE modelo = '$modelo' AND id_user = $id_user");
    $vehiculo = mysqli_fetch_row($buscarId);
    $id_vehiculo = $vehiculo[0];



    $query = "INSERT INTO rides 
                    (salida, llegada, nombre, dia, cantidad, costo, id_veh, id_user, fecha)
                    VALUES 
                    ('$salida', '$llegada', '$nombre', '$dias', '$cantidad', '$costo', '$id_vehiculo', '$id_user', '$fecha')";

    if (mysqli_query($conexion, $query)) {
?>
        <script>
            alert('Ride registrado con exito.');
            window.location.href = 'myRides.php';
        </script>
    <?php
    } else {
    ?>
        <script>
            alert('Error al registrar Ride.');
            window.history.back();
        </script>
<?php
    }
}

include('cerrar_con.php');
