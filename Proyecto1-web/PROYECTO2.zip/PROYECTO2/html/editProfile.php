<?php
session_start();
include("abrir_con.php");

$id_user = $_SESSION['id_user'];
$queryUser = mysqli_query($conexion, "SELECT * FROM usuarios WHERE id = $id_user");
$user = mysqli_fetch_assoc($queryUser);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/editProfile.css" />
    <title>Edit Profile</title>
</head>

<body>
    <main class="container">
        <header class="logo">
            <img src="../imagenes/logoAventones.png" alt="Logo Aventones" />
        </header>

        <div class="navContainer">
            <nav>
                <a href="searchRides.php" class="boton">Home</a>
                <?php
                $queryTipo = mysqli_query($conexion, "SELECT tipo FROM usuarios WHERE id = $id_user");
                $tipo = mysqli_fetch_row($queryTipo);

                if ($tipo[0] == 'Chofer') {
                ?>
                    <a href="myRides.php" class="boton">Rides</a>
                <?php
                }
                ?>
                <a href="editProfile.php" class="boton Rides">Perfil</a>
                <a href="reservas.php" class="boton">Reservas</a>
            </nav>

            <div class="search">
                <img src="../imagenes/user.png" id="user" alt="User" />
            </div>
        </div>

        <section class="title">
            <h1>Editar Perfil</h1>
            <hr />
        </section>

        <form class="form" enctype="multipart/form-data" method="post" action="editarPerfil.php">

            <div class="row">
                <div class="form-group">
                    <label for="firstName">Nombre</label>
                    <input type="text" id="firstName" name="firstName" value="<?= $user['nombre'] ?>" required>
                </div>

                <div class="form-group">
                    <label for="lastName">Apellido</label>
                    <input type="text" id="lastName" name="lastName" value="<?= $user['apellido'] ?>" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group">
                    <label for="ident">Identificación</label>
                    <input type="text" id="ident" name="ident" value="<?= $user['cedula'] ?>" required>
                </div>

                <div class="form-group">
                    <label for="birthdate">Fecha de Nacimiento</label>
                    <input type="date" id="birthdate" name="birthdate" value="<?= $user['fecha_nacimiento'] ?>" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group">
                    <label for="email">Correo</label>
                    <input type="email" id="email" name="email" value="<?= $user['correo'] ?>" required>
                </div>

                <div class="form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="text" id="telefono" name="telefono" value="<?= $user['telefono'] ?>" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <input type="password" id="password" name="password" value="<?= $user['contrasena'] ?>" required>
                </div>

                <div class="form-group">
                    <label for="repeatPassword">Repetir Contraseña</label>
                    <input type="password" id="repeatPassword" name="repeatPassword" value="<?= $user['contrasena'] ?>" required>
                </div>
            </div>

            <div class="row">
                <div class="form-group">
                    <label>Foto actual</label><br>
                    <img src="<?= $user['fotografia'] ?>" width="150">
                </div>

                <div class="form-group">
                    <label for="foto">Nueva Foto</label>
                    <input type="file" id="foto" name="foto" accept="image/*" />
                </div>
            </div>

            <button class="btn-aceptar" name="guardar" type="submit">Guardar</button>
        </form>
    </main>

</body>

</html>

<?php
include('cerrar_con.php');
?>