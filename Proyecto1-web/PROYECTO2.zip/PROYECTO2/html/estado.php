<?php
include("abrir_con.php");


if (isset($_GET['id']) && isset($_GET['estado'])) {
    $id = $_GET['id'];
    $estado = $_GET['estado'];

    if ($estado == 'Inactivo' || $estado == 'Pendiente') {
        actualizarEstado($conexion, 'Activo', $id);
    } else {
        actualizarEstado($conexion, 'Inactivo', $id);
    }

?>
    <script>
        window.location.href = 'admin.php';
    </script>
<?php
}

function actualizarEstado($conexion, $estado, $id)
{
    mysqli_query($conexion, "UPDATE usuarios SET estado = '$estado' WHERE id = $id");
}

include("cerrar_con.php");
