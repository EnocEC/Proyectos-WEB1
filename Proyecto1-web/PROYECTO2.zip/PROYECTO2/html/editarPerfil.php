<?php
session_start();
include("abrir_con.php");

if (isset($_POST['guardar'])) {
    $id = $_SESSION["id_user"];
    $nombre = $_POST['firstName'];
    $apellido = $_POST['lastName'];
    $cedula = $_POST['ident'];
    $fecha_nacimiento = $_POST['birthdate'];
    $correo = $_POST['email'];
    $telefono = $_POST['telefono'];
    $contrasena = $_POST['password'];
    $repetir = $_POST['repeatPassword'];

    if ($contrasena != $repetir) {
        echo "<script>
                alert('Las contraseñas no coinciden');
                window.history.back();
              </script>";
        exit;
    }

    if (!empty($_FILES['foto']['name'])) {
        $nombreImagen = $_FILES['foto']['name'];
        $rutaTemporal = $_FILES['foto']['tmp_name'];
        $carpetaDestino = "../imagenes/" . $nombreImagen;

        move_uploaded_file($rutaTemporal, $carpetaDestino);

        $consulta = "UPDATE usuarios 
                     SET nombre='$nombre', apellido='$apellido', cedula='$cedula', fecha_nacimiento='$fecha_nacimiento', 
                         correo='$correo', telefono='$telefono', contrasena='$contrasena', fotografia='$carpetaDestino'
                     WHERE id='$id'";
    } else {
        $consulta = "UPDATE usuarios 
                     SET nombre='$nombre', apellido='$apellido', cedula='$cedula', fecha_nacimiento='$fecha_nacimiento', 
                         correo='$correo', telefono='$telefono', contrasena='$contrasena'
                     WHERE id='$id'";
    }

    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
?>
        <script>
            alert('Perfil actualizado correctamente.');
            window.location.href = 'searchRides.php';
        </script>
    <?php
    } else {
    ?>
        <script>
            alert('Error al actualizar el perfil.');
            window.history.back();
        </script>;
<?php
    }
}
?>