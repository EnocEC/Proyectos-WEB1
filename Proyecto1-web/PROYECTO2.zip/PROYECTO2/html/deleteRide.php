<?php
include("abrir_con.php");

$id_ride = $_GET['id'];

$query = "DELETE FROM rides WHERE id = $id_ride";

if (mysqli_query($conexion, $query)) {
?>
    <script>
        alert('Ride eliminado con exito.');
        window.location.href = 'myRides.php';
    </script>
<?php
} else {
?>
    <script>
        alert('Error al eliminar Ride.');
        window.history.back();
    </script>
<?php
}

include("cerrar_con.php");
?>