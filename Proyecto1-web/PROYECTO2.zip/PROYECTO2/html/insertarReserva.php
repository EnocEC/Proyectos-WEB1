<?php
session_start();
include("abrir_con.php");
date_default_timezone_set('America/Costa_Rica');

$id_ride = $_GET['id'];
$id_pasajero = $_SESSION['id_user'];

$query = mysqli_query($conexion, "SELECT * FROM rides WHERE id = $id_ride");
$ride = mysqli_fetch_assoc($query);

$id_driver = $ride['id_user'];

$chofer = mysqli_query($conexion, "SELECT * FROM usuarios WHERE id = $id_driver");
$datos_chofer = mysqli_fetch_assoc($chofer);

$nombre_chofer = $datos_chofer['nombre'];
$recorrido = $ride['salida'] . '-' . $ride['llegada'];
$fecha = date('Y-m-d');
$estado = 'Pendiente';

$insertar = "INSERT INTO reservas (chofer, id_ride, recorrido, fecha, estado, id_pasajero)
VALUES ('$nombre_chofer', $id_ride, '$recorrido', '$fecha', '$estado',$id_pasajero)";

if (mysqli_query($conexion, $insertar)) {
    echo "<script>
        alert('Reserva realizada con éxito.');
        window.location.href = 'reservas.php';
    </script>";
} else {
    echo "<script>
        alert('Error al realizar la reserva. Por favor, inténtelo de nuevo.');
        window.location.href = 'searchRides.php';
    </script>";
}
