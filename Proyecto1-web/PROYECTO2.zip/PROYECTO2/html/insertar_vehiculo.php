<?php
session_start();
include("abrir_con.php");

if (isset($_POST['guardar'])) {
    $placa = $_POST["placa"];
    $color = $_POST["color"];
    $marca = $_POST["marca"];
    $modelo = $_POST["modelo"];
    $anio = $_POST["anio"];
    $espacios = $_POST["espacios"];
    $id_user = $_SESSION['id_user'];

    $nombreImagen = $_FILES['foto']['name'];
    $rutaTemporal = $_FILES['foto']['tmp_name'];
    $carpetaDestino = "../imagenes/" . $nombreImagen;

    $validarModelo = mysqli_query($conexion, "SELECT modelo FROM vehiculos WHERE modelo = '$modelo' AND id_user = $id_user");
    if (mysqli_num_rows($validarModelo) > 0) {
?>
        <script>
            alert('Ya has registrado un vehículo con este modelo.');
            window.history.back();
        </script>
        <?php
        exit;
    }

    if (move_uploaded_file($rutaTemporal, $carpetaDestino)) {


        $query = "INSERT INTO vehiculos 
                    (placa, color, marca, modelo, anio, espacios, foto, id_user)
                    VALUES 
                    ('$placa', '$color', '$marca', '$modelo', '$anio', '$espacios', '$carpetaDestino', '$id_user')";

        if (mysqli_query($conexion, $query)) {
        ?>
            <script>
                alert('Registro de vehiculo exitoso');
                window.location.href = 'vehiculos.php';
            </script>
        <?php
        } else {
        ?>
            <script>
                alert('Error al registrar vehiculo.');
                window.history.back();
            </script>;
    <?php
        }
    }
} else {
    ?>
    <script>
        alert('Error al subir la imagen.');
        window.history.back();
    </script>;
<?php
}


include('cerrar_con.php');
?>