<?php
if(session_status() == PHP_SESSION_ACTIVE){
    session_unset();
    session_destroy();
}

session_start();
include("abrir_con.php");

if (isset($_POST['inicio']) && $conexion) {
    $correo = trim($_POST['correo']);
    $contrasena = trim($_POST['password']);

    $_SESSION['email'] = $correo;

    $consulta = mysqli_query($conexion, "SELECT id,tipo FROM usuarios WHERE correo='$correo' AND contrasena='$contrasena' AND estado='Activo'");
    $res = mysqli_fetch_row($consulta);

    $_SESSION['id_user'] = $res[0];
    $tipo = $res[1];

    $_SESSION['tipo'] = $tipo;

    if ($tipo == "Administrador") {
        header("Location: admin.php");
    } elseif ($tipo == "Pasajero") {
        header("Location: searchRides.php");
    } elseif ($tipo == "Chofer") {
        header("Location: myRides.php");
    } else {
?>
        <script>
            alert('Usuario o contraseña incorrectos o cuenta inactiva.');
            window.location.href = 'index.html';
        </script>
<?php
    }
}

include("cerrar_con.php");
?>
