<?php
function validarRide($conexion, $id_user)
{
    $queryUser = mysqli_query($conexion, "SELECT tipo FROM usuarios WHERE id = $id_user");
    $user = mysqli_fetch_row($queryUser);

    if ($user[0] == 'Chofer') {
?>
        <a href="myRides.php" class="boton">Rides</a>
<?php
    }
}
?>