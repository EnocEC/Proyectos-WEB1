<?php
include("abrir_con.php");

date_default_timezone_set('America/Costa_Rica');
$fecha = date('Y-m-d\TH:i');

$id = $_GET['id'];

$query = "SELECT * FROM rides WHERE id = $id";
$resultRide = mysqli_query($conexion, $query);

$ride = mysqli_fetch_assoc($resultRide);

$id_user = $ride['id_user'];

$queryVehi = mysqli_query($conexion, "SELECT id,modelo FROM vehiculos WHERE id_user = $id_user");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../css/editRide.css" />
  <title>Edit Ride</title>
</head>

<body>
  <main class="container">
    <header class="logo">
      <img src="../imagenes/logoAventones.png" alt="Logo Aventones" />
    </header>

    <div class="navContainer">
      <nav>
        <a href="searchRides.php" class="boton">Inicio</a>
        <a href="myRides.php" class="boton Rides">Rides</a>
        <a href="reservas.php" class="boton">Reservas</a>
        <a href="editProfile.php" class="boton">Perfil</a>
      </nav>

      <div class="search">
        <img src="../imagenes/user.png" id="user" alt="User" />

      </div>
    </div>

    <section class="title">
      <h1>Editar Ride</h1>
      <hr />
    </section>

    <form method="post" action="actualizarRide.php?id=<?= $ride['id'] ?>">


      <div class="cont-ruta">
        <div class="datos">
          <label for="departure">Salida</label>
          <input type="text" class="campos" value="<?= $ride['salida'] ?>" name="salida" required />
        </div>

        <div class="datos">
          <label for="arrive">Llegada</label>
          <input type="text" class="campos" value="<?= $ride['llegada'] ?>" name="llegada" required />
        </div>
      </div>

      <br>

      <div class="cont-ruta">
        <div class="datos">
          <label for="nombre">Nombre del Ride</label>
          <input type="text" class="campos" value="<?= $ride['nombre'] ?>" name="nombre" required />
        </div>

        <div class="datos">
          <label for="dias">Día</label>
          <select name="dias" id="dias" class="campos" required>
            <option value="Lunes" <?= $ride['dia'] == 'Lunes' ? 'selected' : '' ?>>Lunes</option>
            <option value="Martes" <?= $ride['dia'] == 'Martes' ? 'selected' : '' ?>>Martes</option>
            <option value="Miercoles" <?= $ride['dia'] == 'Miercoles' ? 'selected' : '' ?>>Miércoles</option>
            <option value="Jueves" <?= $ride['dia'] == 'Jueves' ? 'selected' : '' ?>>Jueves</option>
            <option value="Viernes" <?= $ride['dia'] == 'Viernes' ? 'selected' : '' ?>>Viernes</option>
            <option value="Sabado" <?= $ride['dia'] == 'Sabado' ? 'selected' : '' ?>>Sábado</option>
            <option value="Domingo" <?= $ride['dia'] == 'Domingo' ? 'selected' : '' ?>>Domingo</option>
          </select>
        </div>
      </div>

      <br>

      <br>

      <div class="cont-hora">
        <div class="box2">
          <label>Fecha del Ride</label>
          <br>
          <input class="date" value="<?= date('Y-m-d\TH:i', strtotime($ride['fecha'])) ?>" type="datetime-local" name="fecha" min="<?= $ride['fecha'] ?>" required>
        </div>

        <div class="box2 asiento">
          <label for="cantidad">Asientos</label>
          <br>
          <input class="campo2" type="number" id="cantidad" name="cantidad" value="<?= $ride['cantidad'] ?>" min="1" max="7" required>
        </div>

        <div class="box2">
          <label for="fee">Costo</label>
          <br>
          <input class="campo2" type="text" value="<?= $ride['costo'] ?>" name="costo" required>
        </div>
      </div>

      <br>
      <br>

      <div class="cont-det-veh">
        <div class="box3">
          <label for="make">Modelo de vehiculo a usar</label>
          <br>
          <select name="modelo" class="campos" required>
            <?php while ($vehiculos = mysqli_fetch_assoc($queryVehi)): ?>
              <option value="<?= $vehiculos['modelo'] ?>" <?= $ride['id_veh'] == $vehiculos['id'] ? 'selected' : '' ?>>
                <?= $vehiculos['modelo'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>

      </div>

      <div class="btns-end">
        <a class="btn-canc" href="myRides.html">Cancel</a>
        <button type="submit" class="btn-aceptar" name="btn">Actualizar Ride</button>
      </div>

    </form>
  </main>

</body>

</html>