<?php
include("abrir_con.php");

$salidaFiltro = isset($_GET['salida']) ? $_GET['salida'] : '';
$llegadaFiltro = isset($_GET['llegada']) ? $_GET['llegada'] : '';

$ordenarPor = isset($_GET['ordenarPor']) ? $_GET['ordenarPor'] : 'fecha';
$direccion = isset($_GET['direccion']) ? $_GET['direccion'] : 'ASC';

$query = "SELECT 
    r.id,
    r.salida,
    r.llegada,
    r.cantidad,
    r.costo,
    r.fecha,
    v.marca,
    v.modelo,
    v.anio
FROM rides r
INNER JOIN vehiculos v ON r.id_veh = v.id
WHERE r.fecha >= CURDATE()";

if (!empty($salidaFiltro)) {
    $query .= " AND r.salida = '$salidaFiltro'";
}
if (!empty($llegadaFiltro)) {
    $query .= " AND r.llegada = '$llegadaFiltro'";
}

$query .= " ORDER BY r.$ordenarPor $direccion";

$resultado = mysqli_query($conexion, $query);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/searchRides.css" />
    <title>Search Rides</title>
</head>

<body>
    <main class="container">
        <header class="logo">
            <img src="../imagenes/logoAventones.png" alt="Logo Aventones" />
        </header>

        <div class="navContainer">
            <nav>
                <a href="searchRides.php" class="boton Rides">Inicio</a>
                <?php
                session_start();

                $id_user = $_SESSION['id_user'];
                $queryUser = mysqli_query($conexion, "SELECT tipo FROM usuarios WHERE id = $id_user");
                $user = mysqli_fetch_row($queryUser);

                if ($user[0] == 'Chofer') {
                ?>
                    <a href="myRides.php" class="boton">Rides</a>
                <?php
                }
                ?>
                <a href="editProfile.php" class="boton">Perfil</a>
                <a href="reservas.php" class="boton">Reservas</a>
                <a href="index.html" class="boton">Salir</a>
            </nav>

            <div class="search">
                <img src="../imagenes/user.png" id="user" alt="User" />
            </div>
        </div>

        <section class="title">
            <h1>Rides Disponibles</h1>
            <hr />
        </section>

        <div class="container-info">
            <form method="GET" action="searchRides.php" class="ordenamiento">

                <div class="row dos">
                    <div>
                        <label>Salida</label>
                        <select name="salida" class="partida">
                            <option value="">Seleccione</option>
                            <?php
                            $salidas = mysqli_query($conexion, "SELECT DISTINCT salida FROM rides ORDER BY salida ASC");
                            while ($fila = mysqli_fetch_assoc($salidas)) {
                                $valor = $fila['salida'];
                                $selected = ($salidaFiltro == $valor) ? 'selected' : '';
                                echo "<option value='$valor' $selected>$valor</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div>
                        <label>Llegada</label>
                        <select name="llegada" class="partida">
                            <option value="">Seleccione</option>
                            <?php
                            $llegadas = mysqli_query($conexion, "SELECT DISTINCT llegada FROM rides ORDER BY llegada ASC");
                            while ($fila = mysqli_fetch_assoc($llegadas)) {
                                $valor = $fila['llegada'];
                                $selected = ($llegadaFiltro == $valor) ? 'selected' : '';
                                echo "<option value='$valor' $selected>$valor</option>";
                            }
                            ?>
                        </select>
                    </div>

                </div>

                <br>

                <div class="row dos">
                    <div>
                        <label for="ordenarPor">Ordenar por:</label>
                        <select name="ordenarPor" id="ordenarPor">
                            <option value="fecha" <?= $ordenarPor == 'fecha' ? 'selected' : '' ?>>Fecha</option>
                            <option value="salida" <?= $ordenarPor == 'salida' ? 'selected' : '' ?>>Lugar de Origen</option>
                            <option value="llegada" <?= $ordenarPor == 'llegada' ? 'selected' : '' ?>>Lugar de Destino</option>
                        </select>
                    </div>

                    <div>
                        <label for="direccion">Dirección:</label>
                        <select name="direccion" id="direccion">
                            <option value="ASC" <?= $direccion == 'ASC' ? 'selected' : '' ?>>Ascendente</option>
                            <option value="DESC" <?= $direccion == 'DESC' ? 'selected' : '' ?>>Descendente</option>
                        </select>
                    </div>
                </div>

                <br>
                <button type="submit" class="btn">Aplicar</button>
            </form>
        </div>

        <br><br>

        <div class="table">
            <table>
                <thead>
                    <tr>
                        <th>From</th>
                        <th>To</th>
                        <th>Asientos Disponibles</th>
                        <th>Carro</th>
                        <th>Costo</th>
                        <th>Fecha</th>
                        <th>Solicitar Viaje</th>
                    </tr>
                </thead>

                <tbody>
                    <?php while ($ride = mysqli_fetch_assoc($resultado)) : ?>
                        <tr>
                            <td><?= $ride['salida'] ?></td>
                            <td><?= $ride['llegada'] ?></td>
                            <td><?= $ride['cantidad'] ?></td>
                            <td><?= $ride['marca'] . ' ' . $ride['modelo'] . ' ' . $ride['anio'] ?></td>
                            <td>$<?= $ride['costo'] ?></td>
                            <td><?= $ride['fecha'] ?></td>
                            <td><a href="insertarReserva.php?id=<?= $ride['id'] ?>"
                                    onclick="return confirm('Deseas reservar este viaje')">Solicitar</a></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <br>

        <div id="mapa">
            <img src="../imagenes/mapa.png" alt="mapa" class="image">
        </div>

    </main>

</body>

</html>

<?php
include('cerrar_con.php');
?>