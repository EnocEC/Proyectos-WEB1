<?php
session_start();
include("abrir_con.php");

$id_ride = $_GET['id'];

if (isset($_POST['btn'])) {

    $salida = $_POST['salida'];
    $llegada = $_POST['llegada'];
    $nombre = $_POST['nombre'];
    $dias = $_POST['dias'];
    $cantidad = $_POST['cantidad'];
    $costo = $_POST['costo'];
    $modelo = $_POST['modelo'];
    $fecha = $_POST['fecha'];

    $id_user = $_SESSION['id_user'];

    $buscarId = mysqli_query($conexion, "SELECT id FROM vehiculos WHERE modelo = '$modelo' AND id_user = $id_user");
    $vehiculo = mysqli_fetch_row($buscarId);
    $id_vehiculo = $vehiculo[0];

    if ($cantidad < 1 || $cantidad > 7) {
?>
        <script>
            alert('La cantidad de asientos debe ser entre 1 y 7.');
            window.history.back();
        </script>
    <?php
        exit;
    }

    $query = "UPDATE rides SET
                    salida = '$salida',
                    llegada = '$llegada',
                    nombre = '$nombre',
                    dia = '$dias',
                    cantidad = '$cantidad',
                    costo = '$costo',
                    id_veh = '$id_vehiculo',
                    fecha = '$fecha'
                    WHERE id = $id_ride";

    if (mysqli_query($conexion, $query)) {
    ?>
        <script>
            alert('Ride actualizado con exito.');
            window.location.href = 'myRides.php';
        </script>
    <?php
    } else {
    ?>
        <script>
            alert('Error al actualizar Ride.');
            window.history.back();
        </script>
<?php
    }
}

include('cerrar_con.php');
