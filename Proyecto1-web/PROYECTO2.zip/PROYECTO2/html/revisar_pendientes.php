<?php
declare(strict_types=1);

require_once __DIR__ . '/abrir_con.php';
require_once __DIR__ . '/enviar_correo.php';

echo "=== VERIFICANDO RESERVAS PENDIENTES ===\n\n";

$minutosLimite = 2; 

$sql = "
    SELECT 
        r.id AS reserva_id,
        r.fecha AS fecha_creacion,
        r.estado,
        r.id_ride,
        v.id_user AS chofer_id,
        v.nombre AS ride_nombre,
        v.salida,
        v.llegada,
        v.fecha AS fecha_viaje,
        u.nombre AS chofer_nombre,
        u.apellido AS chofer_apellido,
        u.correo AS chofer_correo
    FROM reservas r
    JOIN rides v ON r.id_ride = v.id
    JOIN usuarios u ON v.id_user = u.id
    WHERE r.estado = 'Pendiente'
      AND TIMESTAMPDIFF(MINUTE, r.fecha, NOW()) > ?
";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $minutosLimite);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "No hay reservas pendientes con más de $minutosLimite minutos.\n";
    exit;
}

echo "Se encontraron " . $result->num_rows . " reservas pendientes.\n\n";

while ($row = $result->fetch_assoc()) {
    $correo = $row['chofer_correo'];
    $nombre = $row['chofer_nombre'] . ' ' . $row['chofer_apellido'];
    $asunto = "Tienes una solicitud pendiente en Aventones";

    $mensajeHTML = "
        <h2>Hola, $nombre 👋</h2>
        <p>Tienes una nueva <strong>solicitud de reserva</strong> pendiente por más de $minutosLimite minutos.</p>
        <p><b>Viaje:</b> {$row['ride_nombre']}<br>
        <b>Origen:</b> {$row['salida']}<br>
        <b>Destino:</b> {$row['llegada']}<br>
        <b>Fecha del viaje:</b> {$row['fecha_viaje']}</p>
        <p>Por favor revisa tu cuenta de Aventones para aceptarla o rechazarla.</p>
        <hr>
        <small>Este es un mensaje automático. No respondas a este correo.</small>
    ";

    $enviado = enviarCorreo($correo, $asunto, $mensajeHTML);

    if ($enviado) {
        echo "✔ Correo enviado a $nombre ($correo)\n";
    } else {
        echo "❌ Error al enviar correo a $nombre ($correo)\n";
    }
}

$stmt->close();
$conexion->close();

echo "\n=== PROCESO FINALIZADO ===\n";
