<?php
include('abrir_con.php');
include('enviar_correo.php');

if (isset($_POST['guardar'])) {

    $nombre = $_POST['firstName'];
    $apellido = $_POST['lastName'];
    $cedula = $_POST['ident'];
    $fecha_nacimiento = $_POST['birthdate'];
    $correo = $_POST['email'];
    $telefono = $_POST['telefono'];
    $contrasena = $_POST['password'];
    $repetir = $_POST['repeatPassword'];
    $tipo = $_POST['tipo'];

    if ($contrasena != $repetir) {
        echo "<script>
                alert('Las contraseñas no coinciden');
                window.history.back();
              </script>";
        exit;
    }

    $nombreImagen = $_FILES['foto']['name'];
    $rutaTemporal = $_FILES['foto']['tmp_name'];
    $carpetaDestino = "../imagenes/" . $nombreImagen;

    if (move_uploaded_file($rutaTemporal, $carpetaDestino)) {
        $token = bin2hex(random_bytes(16));

        $asunto = "Activación de cuenta - Aventones";
        $mensajeHTML = "<p>Hola <b>$nombre</b>,</p>
            <p>Gracias por registrarte. Activa tu cuenta haciendo clic en el siguiente enlace:</p>
            <p><a href='http://localhost/practicas/Proyectos/PROYECTO2/html/activar.php?token=$token'>
            Activar cuenta</a></p>
            <p>Si no solicitaste esta cuenta, ignora este mensaje.</p>";

        if (enviarCorreo($correo, $asunto, $mensajeHTML)) {

            $query = "INSERT INTO usuarios 
                    (nombre, apellido, cedula, fecha_nacimiento, correo, telefono, fotografia, contrasena, estado, tipo, token)
                    VALUES 
                    ('$nombre', '$apellido', '$cedula', '$fecha_nacimiento', '$correo', '$telefono', '$carpetaDestino', '$contrasena', 
                    'Pendiente', '$tipo', '$token')";

            if (mysqli_query($conexion, $query)) {
                echo "<script>
                        alert('Registro exitoso. Revisa tu correo para activar tu cuenta.');
                        window.location.href = 'index.html';
                      </script>";
            } else {
                echo "<script>
                        alert('Error al registrar usuario.');
                        window.history.back();
                      </script>";
            }

        } else {
            echo "<script>
                    alert('Error al enviar el correo. Intente de nuevo.');
                    window.history.back();
                  </script>";
        }

    } else {
        echo "<script>
                alert('Error al subir la imagen.');
                window.history.back();
              </script>";
    }
}

include('cerrar_con.php');
?>
