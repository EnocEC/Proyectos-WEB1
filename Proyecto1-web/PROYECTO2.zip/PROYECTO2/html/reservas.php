<?php
session_start();
include('abrir_con.php');
include('funcionValidarRide.php');

$id_user = $_SESSION['id_user'];
$rol = $_SESSION['tipo']; 
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bookings.css">
    <title>Bookings</title>
</head>

<body>
    <main class="container">
        <header class="logo">
            <img src="../imagenes/logoAventones.png" alt="Logo Aventones">
        </header>

        <div class="navContainer">
            <nav>
                <a href="searchRides.php" class="boton">Inicio</a>
                <?php validarRide($conexion, $id_user); ?>
                <a href="reservas.php" class="boton Rides">Reservas</a>
                <a href="editProfile.php" class="boton">Perfil</a>
            </nav>

            <div class="search">
                <img src="../imagenes/user.png" id="user" alt="User">
            </div>
        </div>

        <section class="title">
            <h1>Reservas</h1>
            <hr>
        </section>

        <table class="cont-tabla">
            <thead>
                <tr>
                    <th>Recorrido</th>
                    <th>Fecha</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($rol == 'Chofer') {
                    $reservas = mysqli_query($conexion, "
                        SELECT * FROM reservas 
                        WHERE chofer = (SELECT nombre FROM usuarios WHERE id = $id_user)
                    ");
                } else {
                    $reservas = mysqli_query($conexion, "
                        SELECT * FROM reservas 
                        WHERE id_pasajero = $id_user
                    ");
                }

                if (mysqli_num_rows($reservas) > 0):
                    while ($res = mysqli_fetch_assoc($reservas)):
                ?>
                        <tr>
                            <td><?= $res['recorrido'] ?></td>
                            <td><?= $res['fecha'] ?></td>
                            <td><?= $res['estado'] ?></td>
                            <td>
                                <?php if ($rol == 'Chofer' && $res['estado'] == 'Pendiente'): ?>
                                    <a href="actualizarReserva.php?id=<?= $res['id'] ?>&accion=aceptar">Aceptar</a> |
                                    <a href="actualizarReserva.php?id=<?= $res['id'] ?>&accion=rechazar">Rechazar</a>
                                <?php elseif ($rol == 'Pasajero' && $res['estado'] == 'Pendiente'): ?>
                                    <a href="actualizarReserva.php?id=<?= $res['id'] ?>&accion=cancelar">Cancelar</a>
                                <?php else: ?>
                                    Sin acciones
                                <?php endif; ?>
                            </td>
                        </tr>
                <?php 
                    endwhile; 
                else: 
                ?>
                        <tr>
                            <td colspan="4">No hay reservas disponibles.</td>
                        </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

</body>

</html>

<?php include('cerrar_con.php'); ?>
