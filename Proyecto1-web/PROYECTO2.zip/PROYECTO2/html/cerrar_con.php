<?php
    if(isset($conexion)) {
        mysqli_close($conexion);
    };
?>