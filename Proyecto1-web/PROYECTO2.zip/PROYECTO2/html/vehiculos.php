<?php
session_start();

include("abrir_con.php");
$id = $_SESSION['id_user'];

$consulta = mysqli_query($conexion, "SELECT * FROM vehiculos WHERE id_user = $id");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/myRides.css">
    <title>Vehiculos</title>

</head>

<body>

    <main class="container">
        <header class="logo">
            <img src="../imagenes/logoAventones.png" alt="Logo Aventones">
        </header>

        <div class="navContainer">
            <nav>
                <a href="searchRides.php" class="boton">Inicio</a>
                <a href="myRides.php" class="boton">Rides</a>
                <a href="reservas.php" class="boton">Reservas</a>
                <a href="vehiculos.php" class="boton Rides">Vehiculos</a>
                <a href="editProfile.php" class="boton">Perfil</a>
            </nav>

            <div class="search">
                <img src="../imagenes/user.png" id="user" alt="User">

            </div>

        </div>

        <section class="title">
            <h1>Vehiculos</h1>
            <hr>
        </section>

        <div class="newRide">
            <a href="registrarVehiculo.html" class="boton newR">Nuevo Vehiculo</a>
        </div>

        <div class="table">
            <table>
                <thead>
                    <tr>
                        <th>Placa</th>
                        <th>Color</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Año</th>
                        <th>Espacios</th>
                        <th>Foto</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                    <?php while ($res = mysqli_fetch_assoc($consulta)): ?>
                        <tr>
                            <td><?= $res['placa'] ?></td>
                            <td><?= $res['color'] ?></td>
                            <td><?= $res['marca'] ?></td>
                            <td><?= $res['modelo'] ?></td>
                            <td><?= $res['anio'] ?></td>
                            <td><?= $res['espacios'] ?></td>
                            <td><img src="<?= $res['foto'] ?>" width="100"></td>
                            <td><a href="editarVehiculo.php?id=<?= $res['id'] ?>">Edit</a> | 
                            <a href="eliminarVehiculo.php?id=<?= $res['id'] ?>" 
                            onclick="return confirm('¿Deseas eliminar este vehículo?');">Delete</a></td>
                        </tr>
                    <?php endwhile; ?>

                </tbody>
            </table>
        </div>

    </main>
</body>

</html>