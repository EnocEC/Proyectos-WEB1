<?php
include("abrir_con.php");

if (isset($_POST['guardar'])) {
    $id = $_POST["id"];
    $placa = $_POST["placa"];
    $color = $_POST["color"];
    $marca = $_POST["marca"];
    $modelo = $_POST["modelo"];
    $anio = $_POST["anio"];
    $espacios = $_POST["espacios"];

    if (!empty($_FILES['foto']['name'])) {
        $nombreImagen = $_FILES['foto']['name'];
        $rutaTemporal = $_FILES['foto']['tmp_name'];
        $carpetaDestino = "../imagenes/" . $nombreImagen;

        move_uploaded_file($rutaTemporal, $carpetaDestino);

        $consulta = "UPDATE vehiculos 
                     SET placa='$placa', color='$color', marca='$marca', modelo='$modelo', 
                         anio='$anio', espacios='$espacios', foto='$carpetaDestino'
                     WHERE id='$id'";
    } else {
        $consulta = "UPDATE vehiculos 
                     SET placa='$placa', color='$color', marca='$marca', modelo='$modelo', 
                         anio='$anio', espacios='$espacios'
                     WHERE id='$id'";
    }

    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
?>
        <script>
            alert('Vehículo actualizado correctamente.');
            window.location.href = 'vehiculos.php';
        </script>
    <?php
    } else {
    ?>
        <script>
            alert('Error al actualizar el vehículo.');
            window.history.back();
        </script>;
<?php
    }
}
?>