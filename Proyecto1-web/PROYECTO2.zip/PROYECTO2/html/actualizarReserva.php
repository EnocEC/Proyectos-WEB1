<?php
include("abrir_con.php");

if (isset($_GET['id']) && isset($_GET['accion'])) {
    $id = $_GET['id'];
    $accion = $_GET['accion'];

    switch ($accion) {
        case 'aceptar':
            $nuevoEstado = 'Aceptada';
            break;
        case 'rechazar':
            $nuevoEstado = 'Rechazada';
            break;
        case 'cancelar':
            $nuevoEstado = 'Cancelada';
            break;
        default:
            $nuevoEstado = 'Pendiente';
            break;
    }

    $consulta = "UPDATE reservas SET estado='$nuevoEstado' WHERE id='$id'";
    $resultado = mysqli_query($conexion, $consulta);

    if ($resultado) {
        echo "<script>
                alert('Estado de la reserva actualizado correctamente.');
                window.location.href='reservas.php';
              </script>";
    } else {
        echo "<script>
                alert('Error al actualizar la reserva.');
                window.location.href='reservas.php';
              </script>";
    }
}
?>
