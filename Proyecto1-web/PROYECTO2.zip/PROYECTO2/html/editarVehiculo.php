<?php
include("abrir_con.php");

$id = $_GET['id'];

$consulta = mysqli_query($conexion, "SELECT * FROM vehiculos WHERE id = $id");
$vehiculo = mysqli_fetch_assoc($consulta);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Vehículo</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

    <main class="container">
        <header class="logo">
            <img src="../imagenes/logoAventones.png" alt="Logo Aventones">
        </header>

        <section class="registration">
            <h1>Editar Vehículo</h1>
            <hr>

            <form class="form" enctype="multipart/form-data" method="post" action="editVehicleProceso.php">

                <div class="row">
                    <div class="form-group">
                        <label for="placa">Placa</label>
                        <input type="text" id="placa" name="placa" value="<?= $vehiculo['placa'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="color">Color</label>
                        <input type="text" id="color" name="color" value="<?= $vehiculo['color'] ?>" required>
                    </div>

                </div>

                <div class="row">
                    <div class="form-group">
                        <label for="marca">Marca</label>
                        <input type="text" id="marca" name="marca" value="<?= $vehiculo['marca'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="modelo">Modelo</label>
                        <input type="text" id="modelo" name="modelo" value="<?= $vehiculo['modelo'] ?>" required>
                    </div>

                </div>

                <div class="row">
                    <div class="form-group">
                        <label for="email">Año</label>
                        <input type="number" id="anio" name="anio" min="2010" max="2026" value="<?= $vehiculo['anio'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="espacios">Espacios</label>
                        <input type="number" id="espacios" name="espacios" min="1" max="60" value="<?= $vehiculo['espacios'] ?>" required>
                    </div>

                </div>

                <div class="form-group full-width">
                    <label>Foto actual</label><br>
                    <img src="<?= $vehiculo['foto'] ?>" width="200">
                </div>


                <div class="form-group full-width">
                    <label for="foto">Foto</label>
                    <input type="file" id="foto" name="foto" accept="image/*"/>
                </div>

                <button id="boton" name="guardar" type="submit">Guardar</button>

            </form>
        </section>
    </main>

    <footer>
        <hr>
        <nav class="footer-links">
            <a href="#">Home</a> |
            <a href="#">Rides</a> |
            <a href="#">Bookings</a> |
            <a href="#">Settings</a> |
            <a href="login.html">Login</a> |
            <a href="index.html">Register</a>
        </nav>
        <p class="footer-copy">© Aventones.com</p>
    </footer>

</body>

</html>