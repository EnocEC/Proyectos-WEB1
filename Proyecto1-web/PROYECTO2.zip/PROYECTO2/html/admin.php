<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Principal</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>

<body>
    <h1>Administradores</h1>
    <hr>

    <div class="cont_principal">
        <a href="formAdmin.php" class="boton">Nuevo administrador</a>

        <table>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Identificacion</th>
                    <th>Fecha de Nacimiento</th>
                    <th>Correo</th>
                    <th>Telefono</th>
                    <th>Fotografia</th>
                    <th>Estado</th>
                    <th>Tipo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                session_start();
                include("abrir_con.php");

                $correo = null;

                if(isset($_SESSION['email'])){
                    $correo = $_SESSION['email'];
                }

                $query = "SELECT * FROM usuarios WHERE correo != '$correo'";
                $respuesta = mysqli_query($conexion, $query);
                ?>

                <?php while ($fila = mysqli_fetch_assoc($respuesta)): ?>
                    <tr>
                        <td><?= $fila['id']  ?></td>
                        <td><?= $fila['nombre'] ?></td>
                        <td><?= $fila['apellido'] ?></td>
                        <td><?= $fila['cedula'] ?></td>
                        <td><?= $fila['fecha_nacimiento'] ?></td>
                        <td><?= $fila['correo'] ?></td>
                        <td><?= $fila['telefono'] ?></td>
                        <td><img src="<?= $fila['fotografia'] ?>" width="75"></td>
                        <td><?= $fila['estado'] ?></td>
                        <td><?= $fila['tipo'] ?></td>
                        <td>
                            <?php
                            if($fila['estado'] == 'Inactivo' || $fila['estado'] == 'Pendiente'){
                                $texto = 'Habilitar';
                            } else {
                                $texto = 'Deshabilitar';
                            }
                            ?>
                            <a href="estado.php?id=<?= $fila['id'] ?>&&estado=<?= $fila['estado']?>" 
                               onclick="return confirm('Desea cambiar el estado del usuario')"> <?= $texto ?>
                            </a>
                        </td>
                    </tr>

                <?php endwhile; ?>

            </tbody>
        </table>
    </div>

</body>

</html>
