<?php
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "aventones";

    $conexion = new mysqli($host, $user, $password, $database);
?>