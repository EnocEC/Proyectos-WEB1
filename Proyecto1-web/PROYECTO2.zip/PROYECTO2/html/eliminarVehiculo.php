<?php
include("abrir_con.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $consulta = "DELETE FROM vehiculos WHERE id='$id'";
    $resultado = mysqli_query($conexion, $consulta);

?>
    <script>
        window.location.href = 'vehiculos.php';
    </script>
<?php
}

?>