<?php
include("abrir_con.php");

if (isset($_POST['btn'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $contrasena = trim($_POST['password']);
    $repetir = trim($_POST['repeatPassword']);

    $tipo = "Administrador";
    $estado = "Activo";
    $token = null;

    $insertar = "INSERT INTO usuarios (nombre, correo, contrasena, tipo, estado, token) 
                 VALUES ('$name', '$email', '$contrasena', '$tipo', '$estado', '$token')";

    $resultado = mysqli_query($conexion, $insertar);

    if ($resultado) {
?>
        <script>
            alert('Administrador registrado correctamente');
            window.location.href = 'login.html';
        </script>
    <?php
    } else {
    ?>
        <script>
            alert('Error al registrar el administrador');
            window.location.href = 'formAdmin.php';
        </script>
<?php
    }

    include("cerrar_con.php");
}
?>