<?php
include('abrir_con.php'); 

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $sql = "SELECT * FROM usuarios WHERE token = '$token'";
    $resultado = mysqli_query($conexion, $sql);

    if (mysqli_num_rows($resultado) > 0) {
        $update = "UPDATE usuarios SET estado = 'Activo', token = NULL WHERE token = '$token'";
        if (mysqli_query($conexion, $update)) {
            echo "<h2>Tu cuenta ha sido activada correctamente.</h2>";
            echo "<a href='login.html'>Inicia sesión aquí</a>";
        } else {
            echo "<h3>Error al activar la cuenta.</h3>";
        }
    } else {
        echo "<h3>Token inválido o ya utilizado.</h3>";
    }
} else {
    echo "<h3>No se proporcionó ningún token.</h3>";
}
?>
