<!DOCTYPE html>
<html lang="es">

<head>
    <title>Registro Administrador</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <main class="container">
        <header class="logo">
            <img src="../imagenes/logoAventones.png" alt="Logo Aventones">
        </header>

        <section class="registration">
            <h1>Registro de Administrador</h1>
            <hr>

            <form class="form" method="post" action="adminRegistro.php">

                <div class="row">
                    <div class="form-group">
                        <label for="firstName">Nombre</label>
                        <input type="text" id="firstName" name="name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Correo</label>
                        <input type="text" id="email" name="email" required>
                    </div>

                </div>

                <div class="row">
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <div class="form-group">
                        <label for="repeatPassword">Repetir Contraseña</label>
                        <input type="password" id="repeatPassword" name="repeatPassword" required>
                    </div>

                </div>

                <button type="submit" id="boton" name="btn">Sign up</button>

            </form>
        </section>
    </main>
</body>

</html>
